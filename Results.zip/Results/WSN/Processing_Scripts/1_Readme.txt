merger.m:  script merges the files with different problem number but same algo
into a single file having all runs (rows) and problems (columns)

stats.m:  script uses the merged results given by merger.m to output mean, stdev, best
and worst. The rows represent the algorithms and columns represent the problem number
